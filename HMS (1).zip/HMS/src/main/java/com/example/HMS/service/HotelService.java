package com.example.HMS.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.HMS.model.Hotel;
import com.example.HMS.repository.HotelRepository;

@Service
public class HotelService {
	
	@Autowired
	private final HotelRepository hotelRepository;

	public HotelService(HotelRepository hotelRepository) {
		super();
		this.hotelRepository = hotelRepository;
	}
	
	@Transactional
	public Hotel saveHotel(String name,String location) {
		Hotel hotels=new Hotel();
		hotels.setId(1);
		hotels.setName(name);
		hotels.setLocation(location);
		return hotelRepository.save(hotels);
	}
	
	
}
