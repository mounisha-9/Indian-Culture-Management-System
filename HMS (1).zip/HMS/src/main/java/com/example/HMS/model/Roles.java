package com.example.HMS.model;

public class Roles {
	public static final String ADMIN ="ROLE_ADMIN";
	public static final String USER ="ROLE_USER";

}
