# Indian-Culture-Management-System
This is a website created using Java Fullstack.It provides detail information and access of Indian cultures.
